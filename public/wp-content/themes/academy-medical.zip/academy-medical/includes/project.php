<?php
/**
 * Custom functions added to current project
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Academy Medical
 * @since 1.0.0
 */

