<?php
/**
 * Block Name: BlockName
 *
 * The template for displaying the custom gutenberg block named BlockName.
 *
 * @link https://www.advancedcustomfields.com/resources/blocks/
 *
 * @package Academy Medical
 * @since 1.0.0
 */

AcademyMedical::block(
	$block,
	function ( $bst_block_id, $bst_block_name, $bst_block_fields, $am_option_fields ) {
		// Block variables.
		?>

		<?php

	}
);

