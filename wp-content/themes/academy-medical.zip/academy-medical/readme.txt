=== Academy Medical ===

Contributors: Glide Design
Tags: one-column, two-columns, custom-menu, full-width-template,  theme-options, translation-ready
Requires at least: 5.3
Tested up to: 5.6
Stable tag: 1.0.0

A Academy Medical WordPress theme

== Description ==

Academy Medical custom WordPress theme by GlideDesign.
